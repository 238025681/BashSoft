package bg.softuni.io;

import bg.softuni.exceptions.InvalidInputException;
import bg.softuni.io.commands.ChangeAbsolutePathCommand;
import bg.softuni.io.commands.ChangeRelativePathCommand;
import bg.softuni.io.commands.Command;
import bg.softuni.io.commands.CompareFilesCommand;
import bg.softuni.io.commands.DownloadAsynchCommand;
import bg.softuni.io.commands.DownloadFileCommand;
import bg.softuni.io.commands.DropDatabaseCommand;
import bg.softuni.io.commands.GetHelpCommand;
import bg.softuni.io.commands.MakeDirectoryCommand;
import bg.softuni.io.commands.OpenFileCommand;
import bg.softuni.io.commands.PrintFilteredStudentsCommand;
import bg.softuni.io.commands.PrintOrderedStudentsCommand;
import bg.softuni.io.commands.ReadDatabaseCommand;
import bg.softuni.io.commands.ShowCourseCommand;
import bg.softuni.io.commands.TraverseFoldersCommand;
import bg.softuni.judge.Tester;
import bg.softuni.network.DownloadManager;
import bg.softuni.repository.StudentsRepository;
import java.io.IOException;

public class CommandInterpreter {

    private Tester tester;
    private StudentsRepository repository;
    private DownloadManager downloadManager;
    private IOManager inputOutputManager;

    public CommandInterpreter(Tester tester,
            StudentsRepository repository,
            DownloadManager downloadManager,
            IOManager inputOutputManager) {

        this.tester = tester;
        this.repository = repository;
        this.downloadManager = downloadManager;
        this.inputOutputManager = inputOutputManager;
    }

    void interpretCommand(String input) throws IOException {
        String[] data = input.split("\\s+");
        String commandName = data[0].toLowerCase();
        try {
            Command command = parseCommand(input, data, commandName);
            command.execute();
        } catch (Throwable t) {
            OutputWriter.displayException(t.getMessage());
        }
    }

    private Command parseCommand(String input, String[] data, String command) throws IOException {
        switch (command) {
            case "open":
                return new OpenFileCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "mkdir":
                return new MakeDirectoryCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "ls":
                return new TraverseFoldersCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "cmp":
                return new CompareFilesCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "cdrel":
                return new ChangeRelativePathCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "cdabs":
                return new ChangeAbsolutePathCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "readdb":
                return new ReadDatabaseCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "help":
                return new GetHelpCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "show":
                return new ShowCourseCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "filter":
                return new PrintFilteredStudentsCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "order":
                return new PrintOrderedStudentsCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "download":
                return new DownloadFileCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "downloadasynch":
                return new DownloadAsynchCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            case "dropdb":
                return new DropDatabaseCommand(input, data, this.tester, this.repository, this.downloadManager, this.inputOutputManager);
            default:
                throw new InvalidInputException(input);
        }

    }

}
