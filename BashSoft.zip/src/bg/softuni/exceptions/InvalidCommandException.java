/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.softuni.exceptions;

import bg.softuni.io.OutputWriter;

/**
 *
 * @author chobi
 */
public class InvalidCommandException extends RuntimeException{
public static final String INVALID_COMMAND = "The command '%s' is invalid"; 


    public InvalidCommandException (String message){
        super(String.format(INVALID_COMMAND, message));
    }
  
    
    
   
    
    
    
}
