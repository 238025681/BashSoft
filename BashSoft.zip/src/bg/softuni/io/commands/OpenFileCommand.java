/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.softuni.io.commands;

import bg.softuni.io.IOManager;
import bg.softuni.judge.Tester;
import bg.softuni.network.DownloadManager;
import bg.softuni.repository.StudentsRepository;

/**
 *
 * @author chobi
 */
public class OpenFileCommand extends Command {

    public OpenFileCommand(String input,
            String[] data,
            Tester tester,
            StudentsRepository repository,
            DownloadManager downloadManager,
            IOManager ioManager) {
        super(input, data, tester, repository, downloadManager, ioManager);
    }

    @Override
    public void execute() throws Exception {
       
    }

}
