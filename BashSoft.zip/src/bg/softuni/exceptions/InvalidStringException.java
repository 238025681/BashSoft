/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.softuni.exceptions;

/**
 *
 * @author chobi
 */
public class InvalidStringException extends RuntimeException{
    public static String NULL_OR_EMPTY_VALUE = "The value of the variable CANNOT be null or empty!";

    public InvalidStringException() {
        super(NULL_OR_EMPTY_VALUE);
    }
    
    public InvalidStringException(String message) {
        super(message);
    }
    
    
}
